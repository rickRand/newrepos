#computer vision library
import cv2

#name the window
cv2.namedWindow("Assignment5.7")

#set variable to video capture
vc= cv2.VideoCapture(0)



#rval is tracker for window if opened
if vc.isOpened(): #try to get first frame
    rval, frame = vc.read()
else:
    rval = False

while rval:
     #any operation on the frame come to imshow
     #while open push frame into window
     cv2.imshow("Assignment5.7", frame)
     rval, frame = vc.read()
     #read keys
     #what key is pressed
     key = cv2.waitKey(20)

     #Capture the current frame from webcam and place in the filename
     if key==32:
        cv2.imwrite('mypicture.jpg',frame)

     #look for escape key...ascii value is 27
     if key== 27:#exit on Esc
        break
#after breaking out of loop
cv2.destroyWindow("Assignment5.7")
rval, frame = vc.read()
#read keys
#what key is pressed

key = cv2.waitKey(20)

