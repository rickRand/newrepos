import tkinter as tk
import tkinter.font as tkFont


#create tkinter object
app = tk.Tk()
#set app title
app.winfo_toplevel().title("Python GUI Example")
#set object size
app.geometry("640x480")

#create font to use in app
fontStyle = tkFont.Font(family="Cooper Black", size = 20)

#create label
labelExample =tk.Label(app, text= "The System is idle", font=fontStyle)



def systemON():
    # change label text into 'system running'
    labelExample.config(text = " System Running")
   

def systemOFF():
    # change label text into 'system off'
    labelExample.config(text = "System Off")
   


#create a virtual image to be used for sizing the buttons in pixels instead of text units
pixelVirtual = tk.PhotoImage(width=1, height=1)

#put the label in the app
labelExample.pack(side=tk.TOP)

# button 
buttonExample1= tk.Button(app, text="System ON", bg="blue" , fg="white" , image=pixelVirtual, width=200, height=100, compound="c", command = systemON)
#use place to give the button a pixel location on screen
buttonExample1.place(x=100,y=400)

buttonExample2= tk.Button(app, text="System OFF", bg="dark red" , fg="white" , image=pixelVirtual, width=200, height=100, compound="c", command = systemOFF)
buttonExample2.place(x=340, y=400)

# minimal exit button 
buttonExample3= tk.Button(app, text="EXIT",bg="dark gray", command = app.quit)
buttonExample3.pack(side=tk.BOTTOM)

app.mainloop()
